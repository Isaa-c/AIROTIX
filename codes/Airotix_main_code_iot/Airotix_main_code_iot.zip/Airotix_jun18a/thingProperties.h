
#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>

const char SSID[]     = SECRET_SSID;    // Network SSID (name)
const char PASS[]     = SECRET_OPTIONAL_PASS;    // Network password (use for WPA, or use as key for WEP)

void onNo2AbnormalThresholdChange();
void onNo2WarningThresholdChange();
void onOzoneAbnormalThresholdChange();
void onOzoneWarningThresholdChange();
void onPm10AbnormalThresholdChange();
void onPm10WarningThresholdChange();
void onPm1AbnormalThresholdChange();
void onPm1WarningThresholdChange();
void onPm25AbnormalThresholdChange();
void onPm25WarningThresholdChange();

float currentSensorPin;
float no2AbnormalThreshold;
float no2ChannelPin;
float no2WarningThreshold;
float ozoneAbnormalThreshold;
float ozonePinInput;
float ozoneWarningThreshold;
float pm10;
float pm1_0;
float pm10AbnormalThreshold;
float pm10WarningThreshold;
float pm1AbnormalThreshold;
float pm1WarningThreshold;
float pm2_5;
float pm2_5AbnormalThreshold;
float pm2_5WarningThreshold;
float powerSensorPin;
float voltageSensorPin;
bool no2AbnormalReached;
bool no2WarningReached;
bool ozoneAbnormalReached;
bool ozoneWarningReached;
bool pm10AbnormalReached;
bool pm10WarningReached;
bool pm1AbnormalReached;
bool pm1WarningReached;
bool pm2_5AbnormalReached;
bool pm2_5WarningReached;

void initProperties(){

  ArduinoCloud.addProperty(currentSensorPin, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(no2AbnormalThreshold, READWRITE, ON_CHANGE, onNo2AbnormalThresholdChange);
  ArduinoCloud.addProperty(no2ChannelPin, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(no2WarningThreshold, READWRITE, ON_CHANGE, onNo2WarningThresholdChange);
  ArduinoCloud.addProperty(ozoneAbnormalThreshold, READWRITE, ON_CHANGE, onOzoneAbnormalThresholdChange);
  ArduinoCloud.addProperty(ozonePinInput, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(ozoneWarningThreshold, READWRITE, ON_CHANGE, onOzoneWarningThresholdChange);
  ArduinoCloud.addProperty(pm10, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm1_0, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm10AbnormalThreshold, READWRITE, ON_CHANGE, onPm10AbnormalThresholdChange);
  ArduinoCloud.addProperty(pm10WarningThreshold, READWRITE, ON_CHANGE, onPm10WarningThresholdChange);
  ArduinoCloud.addProperty(pm1AbnormalThreshold, READWRITE, ON_CHANGE, onPm1AbnormalThresholdChange);
  ArduinoCloud.addProperty(pm1WarningThreshold, READWRITE, ON_CHANGE, onPm1WarningThresholdChange);
  ArduinoCloud.addProperty(pm2_5, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm2_5AbnormalThreshold, READWRITE, ON_CHANGE, onPm25AbnormalThresholdChange);
  ArduinoCloud.addProperty(pm2_5WarningThreshold, READWRITE, ON_CHANGE, onPm25WarningThresholdChange);
  ArduinoCloud.addProperty(powerSensorPin, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(voltageSensorPin, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(no2AbnormalReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(no2WarningReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(ozoneAbnormalReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(ozoneWarningReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm10AbnormalReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm10WarningReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm1AbnormalReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm1WarningReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm2_5AbnormalReached, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(pm2_5WarningReached, READ, ON_CHANGE, NULL);

}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);
